"""
Turn-solver policy: given a battle state, finds the best joint action for
"our" side.

SCOPING DECISION (flagging explicitly): true doubles turn selection is a
simultaneous-move game -- both sides commit actions blind, then they
resolve in speed order. Solving that exactly is a matrix-game / Nash
equilibrium problem, which is a much bigger undertaking than fits here.

Instead this solver does depth-limited EXPECTIMAX against a GREEDY
opponent model: the opponent is assumed to have its active Pokemon each
use whichever of its known top-usage moves does the most immediate damage
(or sets up its known signature tech move on turn 1, e.g. Trick Room /
Tailwind, since that's the standard "obvious" doubles opening for teams
built around it). This is not a game-theoretic guarantee against a
perfect opponent, but it gives concrete, checkable lines against how these
archetypes actually pilot in practice -- which is what "know exactly what
moves to do" needs in practice. The opponent model is swappable/extendable
later (e.g. add a second, more defensive opponent profile and take the
worst case over both).

Our side searches over a pruned action set: each active mon's top-K
known moves (by usage %) + Protect, each damaging move evaluated against
whichever legal target maximizes immediate damage, combined across our
two active mons, then extended `depth` turns using the same opponent
model, scored by a simple HP-differential heuristic at the leaf.
"""
import copy
import itertools

from damage import Combatant, MoveInfo, is_spread_move, effective_stat, damage_roll
from engine import FieldState, Action, on_switch_in, effective_speed
from battle import Battle, Side, PROTECT_MOVES, CHOICE_ITEMS

TOP_K_MOVES = 4   # real sets run 4 moves; 3 systematically under-armed the AI
FIRST_TURN_ONLY_MOVES = {"Fake Out", "First Impression"}


def build_moveset(pokemon_record: dict, moves_db: dict, top_k: int = TOP_K_MOVES,
                   only_moves: list | None = None):
    """Turn mbsmogon usage-% move list into a list of (MoveInfo, usage_pct),
    skipping the 'Other' bucket and non-resolvable move names."""
    out = []
    for mv_name, pct in pokemon_record["moves_usage"]:
        if mv_name == "Other":
            continue
        key = mv_name.lower().replace(" ", "").replace("-", "").replace("'", "")
        if key not in moves_db:
            continue
        m = moves_db[key]
        out.append((MoveInfo(m["name"], m["basePower"], m["type"], m["category"], m["target"],
                              priority=m.get("priority", 0), secondary=m.get("secondary"),
                              self_effect=m.get("self"), boosts=m.get("boosts"),
                              recoil=m.get("recoil"), drain=m.get("drain"),
                              has_crash=bool(m.get("hasCrashDamage")),
                              volatile_status=m.get("volatileStatus"), flags=m.get("flags")), pct))
    if only_moves:
        # Explicit set supplied (e.g. an optimised team sheet) -- use exactly these,
        # preserving the given order, ignoring usage ranking and top_k.
        wanted = {m.lower() for m in only_moves}
        chosen = [(mi, pct) for mi, pct in out if mi.name.lower() in wanted]
        if chosen:
            order = {m.lower(): i for i, m in enumerate(only_moves)}
            chosen.sort(key=lambda x: order.get(x[0].name.lower(), 99))
            return chosen
    out.sort(key=lambda x: -x[1])
    return out[:top_k]


def quick_damage_estimate(attacker: Combatant, target: Combatant, move: MoveInfo,
                           typechart: dict, field: FieldState, num_hit: int = 1) -> float:
    if move.power == 0:
        return 0.0
    atk_key = "atk" if move.category == "Physical" else "spa"
    def_key = "def" if move.category == "Physical" else "spd"
    atk_stat = effective_stat(attacker.stats[atk_key], attacker.stages[atk_key])
    if attacker.item == "Choice Band" and atk_key == "atk":
        atk_stat *= 1.5
    if attacker.item == "Choice Specs" and atk_key == "spa":
        atk_stat *= 1.5
    def_stat = effective_stat(target.stats[def_key], target.stages[def_key])
    _, _, avg, _ = damage_roll(50, move.power, atk_stat, def_stat, attacker, target, move,
                                typechart, weather=field.weather, num_targets_hit=num_hit)
    return avg


def candidate_actions(combatant: Combatant, side_key: str, allies: list, foes: list,
                       moveset, typechart: dict, field: FieldState, turn_num: int,
                       bench: list | None = None):
    """Returns a pruned list of Action objects worth considering for this mon."""
    actions = []
    live_foes = [f for f in foes if not f.fainted]
    # NOTE: do NOT early-return here even if live_foes is empty. That happens
    # legitimately when both opposing actives just fainted this turn and are
    # about to be replaced -- this mon still needs *some* legal action (status
    # moves, Protect) or the whole turn's joint-action search silently breaks
    # (this was a real bug: it looked like a "timeout" but was actually the
    # solver finding zero valid actions and giving up early).

    # Respect an existing Choice item lock: only the already-locked move is legal.
    if combatant.item in CHOICE_ITEMS and combatant.choice_locked_move:
        locked = [m for m in moveset if m[0].name == combatant.choice_locked_move]
        if locked:
            moveset = locked

    # Fake Out / First Impression only work the exact turn the mon was sent out.
    if combatant.active_turn_count > 0:
        moveset = [m for m in moveset if m[0].name not in FIRST_TURN_ONLY_MOVES]

    for move, pct in moveset:
        if move.name in PROTECT_MOVES:
            # Don't offer Protect if it would auto-fail (protected last turn) -- otherwise
            # the search wastes a branch on a guaranteed no-op and can look like it's
            # "choosing" to stall.
            if not combatant.protected_last_turn:
                actions.append(Action(combatant, side_key, "protect", move, [combatant]))
            continue
        if move.category == "Status":
            # Status/setup moves (Trick Room, Tailwind, etc.) -- always offer as a candidate,
            # targeting handled generically (self/allySide/field moves don't need foe targets).
            if move.target in ("self", "allySide", "all"):
                actions.append(Action(combatant, side_key, "move", move, [combatant]))
            continue
        if not live_foes:
            continue  # damaging move but nothing legal to target it at right now
        if is_spread_move(move.target):
            from damage import spread_targets
            tgts = spread_targets(move.target, live_foes, allies, combatant)
            actions.append(Action(combatant, side_key, "move", move, tgts))
        else:
            # single-target: only branch on the target that does more damage (prune to 1)
            best_target = max(
                live_foes,
                key=lambda f: quick_damage_estimate(combatant, f, move, typechart, field)
            )
            actions.append(Action(combatant, side_key, "move", move, [best_target]))

    if not actions:
        # No damaging move had a legal target (e.g. both opposing actives just fainted
        # this turn) and nothing else applied -- fall back to Protect so this mon still
        # has SOME legal action rather than leaving the whole turn's search with nothing.
        actions.append(Action(combatant, side_key, "protect",
                               MoveInfo("Protect", 0, "Normal", "Status", "self", priority=4),
                               [combatant]))

    # Switch candidates: bringing in each available bench mon instead of acting this turn.
    # (Bench Pokemon still take Intimidate/hazard-style switch-in effects via on_switch_in.)
    if bench:
        for b in bench:
            if not b.fainted:
                actions.append(Action(combatant, side_key, "switch", None, [b]))

    return actions


def greedy_opponent_joint_action(battle: Battle, side: Side, opp_side: Side, movesets: dict,
                                  turn_num: int):
    joint = []
    used_incoming = set()
    for c in side.active:
        if c.fainted:
            if side.bench:
                remaining = [b for b in side.bench if id(b) not in used_incoming]
                if remaining:
                    incoming = max(remaining, key=lambda b: b.current_hp_frac)
                    used_incoming.add(id(incoming))
                    joint.append(Action(c, side.name, "switch", None, [incoming]))
            continue
        cands = candidate_actions(c, side.name, side.active, opp_side.active,
                                   movesets[c.name], battle.typechart, battle.field, turn_num)
        # Greedy: prefer a status/setup move on turn 1 only if it's their known signature
        # (Trick Room / Tailwind), else take the highest total estimated damage option.
        def action_value(a: Action):
            if a.kind == "protect":
                return -1  # opponent modeled as not bothering to Protect (simplification)
            if a.move.category == "Status":
                # Speed control (Tailwind / Trick Room) is a genuine board-state swing --
                # a Whimsicott or Talonflame will take it whenever it isn't already up,
                # not just on turn 1, and Prankster/Gale Wings makes it better still.
                if a.move.name in ("Tailwind", "Trick Room"):
                    already = (battle.field.trick_room if a.move.name == "Trick Room"
                               else (battle.field.tailwind_p1 if a.side == "p1"
                                     else battle.field.tailwind_p2) > 0)
                    if already:
                        return -20
                    return 90 if c.ability in ("Prankster", "Gale Wings") else 75
                return 5 if turn_num == 1 else -5
            # Damage must be NORMALISED to the same 0-100 scale the status values use.
            # Previously this returned raw HP damage, so any attack (~150) always beat
            # any status move (<=90) -- which meant Prankster Tailwind, Trick Room,
            # redirection and Protect were effectively never chosen. Value = percentage
            # of the target's remaining HP removed, plus a bonus for actually securing
            # the KO.
            total = 0.0
            own_side = battle.side_of(c)
            for t in a.targets:
                dmg = quick_damage_estimate(c, t, a.move, battle.typechart, battle.field,
                                             num_hit=len(a.targets) if is_spread_move(a.move.target) else 1)
                pct = 100.0 * min(dmg, t.current_hp) / t.max_hp() if t.max_hp() else 0.0
                # An allAdjacent move (Earthquake, Surf, Discharge) also hits our own
                # partner -- that damage counts AGAINST the move, not for it.
                if battle.side_of(t) is own_side:
                    total -= pct * 1.2
                    if dmg >= t.current_hp:
                        total -= 50.0
                else:
                    total += pct
                    if dmg >= t.current_hp:
                        total += 40.0
                        # A KO secured with priority cannot be pre-empted, so it is
                        # strictly better than the same KO in the normal bracket.
                        if a.move.priority > 0:
                            total += 15.0 * a.move.priority
            return total
        best = max(cands, key=action_value) if cands else None
        if best:
            joint.append(best)
    return joint


def heuristic_eval(battle: Battle, my_side_name: str) -> float:
    my = battle.p1 if my_side_name == "p1" else battle.p2
    opp = battle.p2 if my_side_name == "p1" else battle.p1
    if my.has_lost():
        return -10_000
    if opp.has_lost():
        return 10_000
    my_hp = sum(c.current_hp_frac for c in my.roster if not c.fainted)
    # Only count opponents we have actually SEEN -- those on the field now, plus any
    # that have already been revealed (sent out at some point, including fainted
    # ones). Summing their whole roster leaked knowledge of a bench we have not met
    # yet, which let plans quietly assume information the player does not have at
    # the point of choosing a move.
    seen = [c for c in opp.roster
            if c in opp.active or c.fainted or getattr(c, "revealed", False)]
    opp_hp = sum(c.current_hp_frac for c in seen if not c.fainted)
    score = (my_hp - opp_hp) * 100

    # Positional terms. Without these the evaluation is pure HP differential, so a
    # switch -- which costs a turn and usually takes a hit -- can never look good at
    # depth 1, no matter how bad the current board is. These give credit for the
    # things a pivot actually buys.
    score += _positional_score(my, opp, battle.typechart)
    score -= _positional_score(opp, my, battle.typechart)
    return score


# STAB threat proxy: how hard the opposing actives hit what we have out.
def _positional_score(side, foe_side, typechart) -> float:
    from damage import type_multiplier
    total = 0.0
    for c in side.active:
        if c is None or c.fainted:
            continue
        # Accumulated stat drops are a real liability -- an Atk/SpA-dropped attacker
        # (e.g. after Draco Meteor, or two Intimidates) is often worth pivoting out.
        total += sum(v for v in c.stages.values() if v < 0) * 7.0
        total += sum(v for v in c.stages.values() if v > 0) * 4.0

        # A Choice lock is a liability once the locked move is resisted or immune.
        if c.item in CHOICE_ITEMS and c.choice_locked_move:
            total -= 6.0

        # Defensive matchup vs what is actually facing it, using the foes' STAB
        # types as a threat proxy.
        for f in foe_side.active:
            if f is None or f.fainted:
                continue
            worst = max((type_multiplier(t, c.types, typechart) for t in f.types), default=1.0)
            if worst >= 4.0:
                total -= 22.0
            elif worst >= 2.0:
                total -= 11.0
            elif worst <= 0.25:
                total += 9.0
            elif worst <= 0.5:
                total += 5.0
    return total


def our_candidate_joint_actions(battle: Battle, side: Side, opp_side: Side, movesets: dict,
                                 turn_num: int):
    per_mon_options = []
    for c in side.active:
        if c.fainted:
            if side.bench:
                # Forced replacement: must send in a bench member for this empty slot.
                per_mon_options.append([Action(c, side.name, "switch", None, [b]) for b in side.bench])
            continue  # no bench left -> this slot contributes no action
        # Pass the bench so VOLUNTARY switches are candidate actions, not just forced
        # replacements after a faint. Pivoting is a core doubles resource: it resets a
        # Choice lock, escapes accumulated stat drops, and lets a resist absorb a hit
        # that would otherwise lose the board.
        cands = candidate_actions(c, side.name, side.active, opp_side.active,
                                   movesets[c.name], battle.typechart, battle.field, turn_num,
                                   bench=[b for b in side.bench if not b.fainted])
        per_mon_options.append(cands)
    if not per_mon_options:
        return [[]]
    combos = [list(combo) for combo in itertools.product(*per_mon_options)]
    # Filter out combos that try to send the same bench mon into two empty slots at once.
    def valid(combo):
        incoming = [id(a.targets[0]) for a in combo if a.kind == "switch"]
        return len(incoming) == len(set(incoming))
    return [c for c in combos if valid(c)]


def solve_best_action(battle: Battle, my_side_name: str, movesets: dict, depth: int = 1):
    """
    Returns (best_joint_action, expected_score, sim_log) for `my_side_name`
    this turn, searching `depth` turns ahead (depth=1 means "just this turn,
    then heuristic-evaluate the result").
    """
    my_side = battle.p1 if my_side_name == "p1" else battle.p2
    opp_side = battle.p2 if my_side_name == "p1" else battle.p1

    joint_options = our_candidate_joint_actions(battle, my_side, opp_side, movesets, battle.turn_num + 1)

    best_score = -float("inf")
    best_action = None
    best_sim = None

    for my_joint in joint_options:
        sim = copy.deepcopy(battle)
        # Plan DETERMINISTICALLY. If the search explores branches using the same
        # RNG stream the real battle is scored on, it just picks whichever branch
        # the dice happened to favour -- reporting coin flips and 30% flinches as
        # certainties. Planning uses average rolls and no secondary procs; the
        # chosen action is then executed on the real battle, where RNG applies.
        sim.rng = None
        # PLANNING IS DETERMINISTIC. If the search ran with the live RNG it would be
        # planning against the very rolls/flinches/ties it is then scored on, and would
        # simply pick the branch where luck fell its way -- reporting a coin flip or a
        # 30% flinch as a certainty. Plan on the average roll; let the real battle resolve
        # the luck.
        sim.rng = None
        sim.tie_bias = battle.tie_bias
        sim_my_side = sim.p1 if my_side_name == "p1" else sim.p2
        sim_opp_side = sim.p2 if my_side_name == "p1" else sim.p1

        # Re-point the actions' combatant/target refs at the deep-copied objects. Map the
        # FULL roster (not just currently-active mons) so switch-in targets drawn from the
        # bench also resolve to their correct deep-copied counterpart, not a stale pre-copy
        # object -- otherwise a switched-in mon silently desyncs from the roster used for
        # win-condition checks (a real bug this caught: fainted-in-log but alive-in-roster).
        my_map = {id(o): n for o, n in zip(my_side.roster, sim_my_side.roster)}
        opp_map = {id(o): n for o, n in zip(opp_side.roster, sim_opp_side.roster)}
        full_map = {**my_map, **opp_map}

        def remap(a: Action) -> Action:
            return Action(full_map.get(id(a.combatant), a.combatant), a.side, a.kind, a.move,
                          [full_map.get(id(t), t) for t in a.targets])

        my_joint_r = [remap(a) for a in my_joint]
        opp_joint = greedy_opponent_joint_action(sim, sim_opp_side, sim_my_side, movesets,
                                                  sim.turn_num + 1)

        p1_actions = my_joint_r if my_side_name == "p1" else opp_joint
        p2_actions = opp_joint if my_side_name == "p1" else my_joint_r

        sim.run_turn(p1_actions, p2_actions)

        if depth > 1 and not sim.is_over():
            _, future_score, _ = solve_best_action(sim, my_side_name, movesets, depth - 1)
            score = future_score
        else:
            score = heuristic_eval(sim, my_side_name)

        if score > best_score:
            best_score = score
            best_action = my_joint
            best_sim = sim

    return best_action, best_score, best_sim


if __name__ == "__main__":
    from species_data import build_merged_dataset
    from stats import compute_stats

    merged, _, moves, natures, typechart = build_merged_dataset()

    def make_combatant(name):
        p = merged[name]
        nat = natures[p["nature"].lower()]
        stats = compute_stats(p["base_stats"], nat, p["evs"])
        ab = p["abilities_usage"][0][0] if p["abilities_usage"] else ""
        it = p["items_usage"][0][0] if p["items_usage"] else ""
        return Combatant(name=name, stats=stats, types=p["types"], ability=ab, item=it)

    # Our lead: Incineroar + Farigiraf. Enemy lead (from teams.csv "Rain"): Archaludon + Pelipper.
    incineroar = make_combatant("Incineroar")
    farigiraf = make_combatant("Farigiraf")
    archaludon = make_combatant("Archaludon")
    pelipper = make_combatant("Pelipper")

    battle = Battle([incineroar, farigiraf], [archaludon, pelipper], typechart, moves)

    movesets = {}
    for name in ["Incineroar", "Farigiraf", "Archaludon", "Pelipper"]:
        movesets[name] = build_moveset(merged[name], moves)
        print(name, "moveset:", [(m.name, round(pct, 1)) for m, pct in movesets[name]])

    best_action, score, sim = solve_best_action(battle, "p1", movesets, depth=1)
    print("\nBest turn-1 joint action for us:")
    for a in best_action:
        print(f"  {a.combatant.name} -> {a.kind} {a.move.name if a.move else ''} "
              f"targeting {[t.name for t in a.targets]}")
    print(f"Resulting heuristic score: {score:.1f}")
    print("\nSimulated log:")
    print(sim.log.dump())
